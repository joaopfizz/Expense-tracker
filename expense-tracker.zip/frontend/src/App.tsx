import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [amount, setAmount] = useState('');

  useEffect(() => {
    fetch('/expenses').then(res => res.json()).then(setExpenses);
  }, []);

  const addExpense = () => {
    fetch('/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount })
    }).then(res => res.json()).then(exp => setExpenses([...expenses, exp]));
  };

  return (
    <div>
      <h1>Expense Tracker</h1>
      <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" />
      <button onClick={addExpense}>Add</button>
      <ul>
        {expenses.map((e, i) => <li key={i}>${'{'}e.amount{'}'}</li>)}
      </ul>
    </div>
  );
}

export default App;
