CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100)
);

CREATE TABLE expenses (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  amount NUMERIC(10,2),
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Window function example: calculate total and rank per user
SELECT user_id, SUM(amount) AS total_spent,
RANK() OVER (ORDER BY SUM(amount) DESC) AS rank
FROM expenses
GROUP BY user_id;
