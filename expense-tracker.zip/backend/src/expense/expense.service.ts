import { Injectable } from '@nestjs/common';

@Injectable()
export class ExpenseService {
  private expenses = [];

  findAll() {
    return this.expenses;
  }

  create(expense: any) {
    this.expenses.push(expense);
    return expense;
  }
}
